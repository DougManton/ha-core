# Ohme Smart EV Charger API
This package provides classes to manage the authentication, reading and writing
of the Ohme API for EV charge points