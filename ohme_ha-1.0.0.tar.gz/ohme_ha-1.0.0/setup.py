# Always prefer setuptools over distutils
from setuptools import setup, find_packages

# To use a consistent encoding
from codecs import open
from os import path

# The directory containing this file
HERE = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(HERE, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

# This call to setup() does all the work
setup(
    name="ohme_ha",
    version="1.0.0",
    description="An API for interacting with the Ohme EV charger",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DougManton/ohma_ha/",
    author="Doug Manton",
    author_email="github@unnecessary.org",
    license="Apache2",
    classifiers=[
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.10",
        "Operating System :: OS Independent",
    ],
    packages=["ohme_ha"],
    include_package_data=True,
    install_requires=["numpy"],
)
