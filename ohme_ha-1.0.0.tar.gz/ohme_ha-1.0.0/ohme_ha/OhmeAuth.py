import requests
from datetime import datetime
from datetime import timedelta

from .exceptions import OhmeException
from .exceptions import TimeoutException
from .exceptions import WrongCredentials

class OhmeAuth:

  def __init__(self, apikey: str, email: str, password: str):
    self.apikey = apikey
    self.email = email
    self.token = self.startAuth(password)

  def startAuth(self, password: str):
    """Uses entered credentials to generate an authentication token that can be used against the Ohme API.

    :param apikey: The long-lived key for the Ohme API
    :param email: The email address of the charge point owner
    :param password: The password of the charge point owner

    """
    identity={"continueUri":"http://www.google.com/","identifier":self.email}
    verify={"email":self.email,"returnSecureToken":"true","password":password}
    createAuthUri="https://www.googleapis.com/identitytoolkit/v3/relyingparty/createAuthUri?key="
    verifyPasswordUri="https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key="
    try:
      auth = requests.post(createAuthUri+self.apikey,json=identity)
    except:
      raise WrongCredentials()
    if auth.status_code == 200:
      # Obtain the session token
      try:
        key = requests.post(verifyPasswordUri+self.apikey,json=verify)
      except:
        raise WrongCredentials()
      if key.status_code == 200:
        idToken = key.json()["idToken"]
        refreshToken = key.json()["refreshToken"]
        expiresToken = datetime.now()+timedelta(seconds=int(key.json()["expiresIn"])-60)
      else:
        raise OhmeException(key.status_code)

    else:
      raise OhmeException(key.status_code)
    return {"idToken":idToken, "refreshToken":refreshToken, "expiresToken":expiresToken, "apikey":self.apikey}

  def refreshAuth(self):
    if self.token["expiresToken"] >= datetime.now():
      return
    refreshTokenUri="https://securetoken.googleapis.com/v1/token?key="
    refresh={"grantType":"refresh_token","refreshToken":self.token["refreshToken"]}
    try:
      auth = requests.post(refreshTokenUri+self.token["apikey"],json=refresh)
    except:
      raise WrongCredentials()
    if auth.status_code == 200:
      idToken = auth.json()["id_token"]
      refreshToken = auth.json()["refresh_token"]
      expiresToken = datetime.now()+timedelta(seconds=int(auth.json()["expires_in"])-60)
    else:
      raise OhmeException(auth.status_code)
    self.token = {"idToken":idToken, "refreshToken":refreshToken, "expiresToken":expiresToken, "apikey":self.token["apikey"]}
